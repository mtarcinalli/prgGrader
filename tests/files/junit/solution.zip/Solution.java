import org.junit.*;
import static org.junit.Assert.assertEquals;

public class Solution {

    @BeforeClass
    public static void setUpClass() {
        // code executed before all test methods
    }

    @Before
    public void setUp() {
        // code executed before each test method
    }

    @Test
    public void testAdd() {
        Calculator calculator = new Calculator();
        int a = 1234;
        int b = 5678;
        int actual = calculator.add(a, b);

        int expected = 6912;

        assertEquals(expected, actual);
    }

    @Test
    public void testSubtract() {
        Calculator calculator = new Calculator();
        int a = 5678;
        int b = 1234;
        int actual = calculator.subtract(a, b);

        int expected = 4444;

        assertEquals(expected, actual);
    }

    @Test
    public void testMutiply() {
        Calculator calculator = new Calculator();
        int a = 2;
        int b = 5;
        int actual = calculator.multiply(a, b);

        int expected = 10;

        assertEquals(expected, actual);
    }

    @Test
    public void testDivide() {
        Calculator calculator = new Calculator();
        int a = 10;
        int b = 2;
        int actual = calculator.divide(a, b);

        int expected = 5;

        assertEquals(expected, actual);
    }

    @After
    public void tearDown() {
        // code executed after each test method
    }

    @AfterClass
    public static void tearDownClass() {
        // code executed after all test methods
    }
}