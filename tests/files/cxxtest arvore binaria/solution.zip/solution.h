#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>

using namespace std;
#define MAX 5

#include <cxxtest/TestSuite.h>

#include "ArvoreBinaria.cpp"


class MyTestSuite1 : public CxxTest::TestSuite {
public:
    void testeListarInOrdem(void) {
        ArvoreBinaria minhaArvore;
        TS_ASSERT_EQUALS(minhaArvore.listarInOrdem(), "");
        minhaArvore.inserir(6);
        TS_ASSERT_EQUALS(minhaArvore.listarInOrdem(), "[6]");
        minhaArvore.inserir(2);
        TS_ASSERT_EQUALS(minhaArvore.listarInOrdem(), "[2][6]");
        minhaArvore.inserir(8);
        TS_ASSERT_EQUALS(minhaArvore.listarInOrdem(), "[2][6][8]");
        minhaArvore.inserir(11);
        TS_ASSERT_EQUALS(minhaArvore.listarInOrdem(), "[2][6][8][11]");
        minhaArvore.inserir(7);
        TS_ASSERT_EQUALS(minhaArvore.listarInOrdem(), "[2][6][7][8][11]");
        minhaArvore.inserir(1);
        TS_ASSERT_EQUALS(minhaArvore.listarInOrdem(), "[1][2][6][7][8][11]");
        minhaArvore.inserir(3);
        TS_ASSERT_EQUALS(minhaArvore.listarInOrdem(), "[1][2][3][6][7][8][11]");
    }
    
    void testeListarPreOrdem(void) {
        ArvoreBinaria minhaArvore;
        TS_ASSERT_EQUALS(minhaArvore.listarPreOrdem(), "");
        minhaArvore.inserir(6);
        TS_ASSERT_EQUALS(minhaArvore.listarPreOrdem(), "[6]");
        minhaArvore.inserir(2);
        TS_ASSERT_EQUALS(minhaArvore.listarPreOrdem(), "[6][2]");
        minhaArvore.inserir(8);
        TS_ASSERT_EQUALS(minhaArvore.listarPreOrdem(), "[6][2][8]");
        minhaArvore.inserir(11);
        TS_ASSERT_EQUALS(minhaArvore.listarPreOrdem(), "[6][2][8][11]");
        minhaArvore.inserir(7);
        TS_ASSERT_EQUALS(minhaArvore.listarPreOrdem(), "[6][2][8][7][11]");
        minhaArvore.inserir(1);
        TS_ASSERT_EQUALS(minhaArvore.listarPreOrdem(), "[6][2][1][8][7][11]");
        minhaArvore.inserir(3);
        TS_ASSERT_EQUALS(minhaArvore.listarPreOrdem(), "[6][2][1][3][8][7][11]");
    }

    void testeListarPosOrdem(void) {
        ArvoreBinaria minhaArvore;
        TS_ASSERT_EQUALS(minhaArvore.listarPosOrdem(), "");
        minhaArvore.inserir(6);
        TS_ASSERT_EQUALS(minhaArvore.listarPosOrdem(), "[6]");
        minhaArvore.inserir(2);
        TS_ASSERT_EQUALS(minhaArvore.listarPosOrdem(), "[2][6]");
        minhaArvore.inserir(8);
        TS_ASSERT_EQUALS(minhaArvore.listarPosOrdem(), "[2][8][6]");
        minhaArvore.inserir(11);
        TS_ASSERT_EQUALS(minhaArvore.listarPosOrdem(), "[2][11][8][6]");
        minhaArvore.inserir(7);
        TS_ASSERT_EQUALS(minhaArvore.listarPosOrdem(), "[2][7][11][8][6]");
        minhaArvore.inserir(1);
        TS_ASSERT_EQUALS(minhaArvore.listarPosOrdem(), "[1][2][7][11][8][6]");
        minhaArvore.inserir(3);
        TS_ASSERT_EQUALS(minhaArvore.listarPosOrdem(), "[1][3][2][7][11][8][6]");
    }

    void testeMaximo(void) {
        ArvoreBinaria minhaArvore;
        TS_ASSERT_EQUALS(minhaArvore.maximo(), true);
        minhaArvore.inserir(6);
        TS_ASSERT_EQUALS(minhaArvore.maximo(), true);
        minhaArvore.inserir(2);
        TS_ASSERT_EQUALS(minhaArvore.maximo(), false);
        minhaArvore.inserir(8);
        TS_ASSERT_EQUALS(minhaArvore.maximo(), true);
        minhaArvore.inserir(11);
        TS_ASSERT_EQUALS(minhaArvore.maximo(), false);
        minhaArvore.inserir(7);
        TS_ASSERT_EQUALS(minhaArvore.maximo(), false);
        minhaArvore.inserir(1);
        TS_ASSERT_EQUALS(minhaArvore.maximo(), false);
        minhaArvore.inserir(3);
        TS_ASSERT_EQUALS(minhaArvore.maximo(), true);
    }

    void testeEstritamenteBinaria(void) {
        ArvoreBinaria minhaArvore;
        TS_ASSERT_EQUALS(minhaArvore.estritamenteBinaria(), true);
        minhaArvore.inserir(6);
        TS_ASSERT_EQUALS(minhaArvore.estritamenteBinaria(), true);
        minhaArvore.inserir(2);
        TS_ASSERT_EQUALS(minhaArvore.estritamenteBinaria(), false);
        minhaArvore.inserir(8);
        TS_ASSERT_EQUALS(minhaArvore.estritamenteBinaria(), true);
        minhaArvore.inserir(11);
        TS_ASSERT_EQUALS(minhaArvore.estritamenteBinaria(), false);
        minhaArvore.inserir(7);
        TS_ASSERT_EQUALS(minhaArvore.estritamenteBinaria(), true);
        minhaArvore.inserir(1);
        TS_ASSERT_EQUALS(minhaArvore.estritamenteBinaria(), false);
        minhaArvore.inserir(3);
        TS_ASSERT_EQUALS(minhaArvore.estritamenteBinaria(), true);
    }

};
