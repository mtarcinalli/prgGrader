#include <stdio.h>
#include <string.h>

int main(void) {
    double numero1, numero2;
    if (scanf("%lf %lf", &numero1, &numero2) != 2) return 1;
    double resultado = numero1 + numero2;
    char buf[64];
    /* Imprime com precisão suficiente e depois remove zeros à direita */
    snprintf(buf, sizeof(buf), "%.10f", resultado);
    char *p = buf + strlen(buf) - 1;
    while (p > buf && *p == '0') { *p = '\0'; p--; }
    if (p > buf && *p == '.') *p = '\0';
    printf("%s\n", buf);
    return 0;
}
